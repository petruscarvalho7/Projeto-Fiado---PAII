/** Automatically generated file. DO NOT MODIFY */
package com.ufpb.example.execi_pa;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}