package com.example.execi_pa;

public interface BotoesUtilFacade {

	public int randomizerColorButton();
	
}
